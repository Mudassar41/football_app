part of app_theme;

abstract class AppColors {
  static const Color primaryColorLight = Color(0xff8F0103);
  static const Color primaryColorDark = Colors.deepPurple;
}
