abstract class AppImages {
  static const bg = 'assets/images/bg.png';
  static const hLogo = 'assets/images/hlogo.png';
}
