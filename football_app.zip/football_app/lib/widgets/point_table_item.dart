import 'package:flutter/material.dart';

class PointTableItem extends StatelessWidget {
  const PointTableItem({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
