package com.example.football_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
